----------------------------------------------------
Author - Casey Ryane

Course - COMP 2503 Programming III

Instructor -  Laura Marik

----------------------------------------------------
All soruce files are located in the src folder.

A3.jar is a runnable jar file for the assignment
that can be run from the command line.
----------------------------------------------------

