----------------------------------------------------
Author - Casey Ryane

Course - COMP 2503 Programming III

Instructor -  Laura Marik

Assignment - #4

----------------------------------------------------
All soruce files are located in the src folder.

A4.jar is a runnable jar file for the assignment
that can be run from the command line.
----------------------------------------------------

